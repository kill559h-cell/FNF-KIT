# Psych Character To V-Slice Converter

Converts Psych Engine character JSON's to V-Slice compatible character JSON's and vice versa.

# Uso

funciona como un .exe pero ejecuta la terminal asi que tecnicamente puede ser un .py al ser de terminal o un .bat

# modos de conversion

PSYCH_TO_VSLICE para el juego base y VSLICE_TO_PSYCH para los engine

# Notes NO mias en ingles

For Psych Engine to V-Slice conversion, there is currently no support for multi-sparrow Psych characters.

V-Slice to Psych does support multi-sparrow V-Slice characters.
